- Firstly, loading page is made. Then after gaming page is made which is made with the help of 2 desing patterns i.e, Flyweight and Singleton.

- we implemented Serielizable iterface to save or unsave the data of the game.

- Some sound effects are also added in the background.
