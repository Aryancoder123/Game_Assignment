package com.firstgdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
//import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Assets {
    public static Texture sheet;
    public static Texture texture_img2;
    public static Sprite sprite_img;
    public static Sprite sprite_red;
    public static Sprite sprite_blue;
    public static TextureRegion curr_frame;
    private static TextureRegion[] sheet_Frames;
    public static Animation load_animations;
    public static Sound Coolsounds;
    public static Texture texture;
    public static Texture texture_2;
    public static Texture texture_pause;
    public static Texture texture_3;
    public static Texture fire_texture;
    public static Sprite Block;
    public static Sprite Block_2;
    public static Sprite Fire;
    public static Sprite bg_img;
    public static Sprite pause;
    public static void load(){
//        texture_img1 = new Texture(Gdx.files.internal("Skins/img2.png"));
////        region = new TextureRegion(texture_img1,50,50,100,100);
//        texture_img1.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
//        sprite_img = new Sprite(texture_img1);
//        sprite_img.flip(false,true);
//        texture_img2 = new Texture(Gdx.files.internal("Skins/spritesheet.png"));
//        sprite_red = new Sprite(texture_img2,0,0,16,16);
//        sprite_blue = new Sprite(texture_img2,16,0,16,16);
        texture = new Texture(Gdx.files.internal("Skins/My project-1.png"));
        Block = new Sprite(texture);
        fire_texture = new Texture("Skins/.jpeg");
        Fire = new Sprite(fire_texture);
        texture_3 = new Texture(Gdx.files.internal("Skins/My project-1.png"));
        Block_2 = new Sprite(texture_3);
        Block_2.flip(true,false);
        texture_2 = new Texture(Gdx.files.internal("Skins/ap.png"));
        bg_img = new Sprite(texture_2);
        texture_pause = new Texture(Gdx.files.internal("Skins/pause.png"));
        pause = new Sprite(texture_pause);
        pause.flip(false,true);
        Coolsounds = Gdx.audio.newSound(Gdx.files.internal("Skins/coolsound.wav"));
        sheet = new Texture(Gdx.files.internal("Skins/loadingsheet.png"));
        TextureRegion[][] temp = TextureRegion.split(sheet,16,16);
        sheet_Frames = new TextureRegion[12];
        int index = 0;
        for(int i=0;i<3;i++){
            for(int j=0;j<4;j++){
                sheet_Frames[index++] = temp[i][j];
            }
        }
        for(int i=0;i<12;i++){
            sheet_Frames[i].flip(false,true);
        }
        load_animations = new Animation(0.3F,sheet_Frames);
    }
}
