package com.firstgdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import org.w3c.dom.Text;

import java.util.Vector;

interface Saved {
    void Serialzing();
    void DeSerialzing();
}
public class GameScreen extends Game implements Screen {
    private MygdxGame game;
    OrthographicCamera Camera;
    SpriteBatch batch;
    private Sprite sprite;
    public static Stage stage;
    private float stateTime;
    public static final int SPEED = 40;
    public int blocksX;
    public int blocksY;
    public Vector3 touch;
    public boolean paused = false;
    public GameScreen(MygdxGame game) {

        this.game=game;
//        Skin skin = new Skin(Gdx.files.internal("uiskin.json"));
//        btn.setPosition(300,300);
//        btn.setSize(300,60);
//        stage.addActor(btn);
        touch = new Vector3();
        Camera = new OrthographicCamera();
        Camera.setToOrtho(true,1920,1080);
        batch = new SpriteBatch();
        stateTime = 0F;
        blocksX = 1920 - 64;
        blocksY = 1080 - 64;
    }

    @Override
    public void show() {

    }

    public void render(float delta) {
//        super.render();
    }
    public void gen_Update(Vector3 touch, OrthographicCamera camera){
//        if(Gdx.input.isTouched()){
//            touch.set(Gdx.input.getX(),Gdx.input.getY(),0);
//            camera.unproject(touch);
//            if(touch.x>=960 && touch.x<=960+128 && touch.y>=540 && touch.y<540+128){
//                System.out.println("DONT TOUCH ME YOU ASSHOLE!!");
//            }
//            blocksX =(int) touch.x;
//            blocksY =(int) touch.y  ;
//        }
        // FOR KEYBOARD INPUTS...
    }

    @Override
    public void create() {
        this.create();
        batch = new SpriteBatch();
//        this.setScreen(new GameScreens(this));
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }


    @Override
    public void dispose() {

    }
}
