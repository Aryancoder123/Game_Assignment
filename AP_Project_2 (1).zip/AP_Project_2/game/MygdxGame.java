package com.firstgdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.utils.ScreenUtils;

public class MygdxGame extends Game {
	public static Stage stage;
	private GameScreens game_screen;
	private Skin myskin;
//	private Skin skin;
	private TextButton btn;
	TextButton textButtonStyle;
	@Override
	public void create() {
//		stage = new Stage();
//		myskin = new Skin(Gdx.files.internal("Skins/glassy-ui.json.url"));
//		Gdx.input.setInputProcessor(stage);
//		textButtonStyle = new TextButton("Text Button",myskin,"small");
//		textButtonStyle.font = new BitmapFont();
//		textButtonStyle.fontColor = Color.BLACK;
//		stage.addActor(textButtonStyle);
//		stage.draw();
//		skin = new Skin();
//		skin.add("logo",new Texture("Main menu/Tanks.png"));
//		Texture logo = skin.get("logo", Texture.class);
//		Drawable redDrawable = skin.newDrawable("whiteRegion", Color.RED);
//		TextButton button = new TextButton("Click me!!",skin,"bigButton");
		Assets.load();
		game_screen = new GameScreens(this);
		setScreen(game_screen);
	}
}