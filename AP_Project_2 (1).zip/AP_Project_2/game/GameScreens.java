package com.firstgdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;

import java.io.Serializable;
import java.util.HashMap;
//import com.mygamepractice.mygame.MyGdxPracticeGame;

public class GameScreens implements Screen {
    OrthographicCamera Camera;
    //  FOR FLYWEIGHT DESIGN PATTERN
    public HashMap<Integer,Bullets> map = new HashMap<>();
    SpriteBatch batch;
    private Sprite sprite;
    public static Stage stage;
    private float stateTime;
    public static final int SPEED = 6;
    public int blocksX;
    public int blocksY;
    public int blocksX2;
    public int blocksY2;
    public Vector3 touch;
    MygdxGame gs;
    public boolean paused = false;
    public boolean isFired = false;
//    Bullets bullets = new Bullets(0,0);
    Bullets bullets;
    private Skin skin;
    Texture bulletTexture;
    // FOR SINGLETON PATTERN..
//    public Bullets getInstance(Bullets b){
//        if(b != null){
//            return b;
//        }
//        return new Bullets(1,2);
//    }
//    MyGdxPracticeGame game;
    public GameScreens(MygdxGame gs)  {
//        this.game = game;
        this.gs = gs;
        Camera = new OrthographicCamera();
        Camera.setToOrtho(true,1920,1080);
        batch = new SpriteBatch();
//        skin = new Skin(Gdx.files.internal("uiskin.json"));
        blocksX = 10;
        blocksY = 800 ;
        blocksX2 = 1300;
        blocksY2 = 800;
        bullets = new Bullets(blocksX,SPEED);
        bulletTexture = new Texture("Skins/missile.png");

//        TextButton attackButton = new TextButton("Shoot",skin);
//        attackButton.setScale(3.5f);
//        attackButton.setColor(Color.);
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1F,1F,1F,1F);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        Camera.update();
        if(paused){
            if(Gdx.input.isKeyPressed(Input.Keys.SPACE)){
                paused = false;
                try{
                    Thread.sleep(1000);
                }
                catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        }
        else{
            gen_Update(touch,Camera);
            bullets.update();
        }
        stateTime+=Gdx.graphics.getDeltaTime();
//        Assets.curr_frame = (TextureRegion) Assets.load_animations.getKeyFrame(stateTime,true);
//        batch.setProjectionMatrix(Camera.combined);
        batch.begin();

//        batch.draw(Assets.sprite_img,20,100);
//        batch.draw(Assets.curr_frame,256,256);
        // FOR MOVING BLOCK ON TOUCHING OR PRESSING KEYS...
        batch.draw(Assets.texture_2,0,0);
        if(isFired) {
            batch.draw(bulletTexture, bullets.bulletLocn, 250);
            if(bullets.bulletLocn > 1500){
                batch.draw(Assets.Fire, bullets.bulletLocn, 0);
            }
        }
        batch.draw(Assets.Block_2,blocksX2,5);
//        batch.draw(Assets.Block,960,540);
        if(paused){
            batch.draw(Assets.pause,0,0);
        }
        batch.draw(Assets.Block,blocksX,5);
//        stage.act();
//        batch.draw(Assets.sprite_red,50,20);
//        batch.draw(Assets.sprite_blue,100,10);
        batch.end();
//        stage.draw();
    }

    private void gen_Update(Vector3 touch, OrthographicCamera camera) {
        if(Gdx.input.isKeyPressed(Input.Keys.ENTER)){
            isFired = true;
        }
        if(Gdx.input.isKeyPressed(Input.Keys.SPACE)){
            paused = true;
            try{
                Thread.sleep(1000);
            }
            catch(InterruptedException e){
                e.printStackTrace();
            }
        }
        if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){
            blocksX-=SPEED;
        }
        if(Gdx.input.isKeyJustPressed(Input.Keys.A)){
            blocksX2-=SPEED;
        }
//        else if(Gdx.input.isKeyPressed(Input.Keys.W) || Gdx.input.isKeyPressed(Input.Keys.UP)){
//            blocksY+=5;
//        }
//        else if(Gdx.input.isKeyPressed(Input.Keys.S) || Gdx.input.isKeyPressed(Input.Keys.DOWN)){
//            blocksY-=5;
//        }
        if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
            blocksX+=SPEED;
        }
        if(Gdx.input.isKeyPressed(Input.Keys.D)){
            blocksX2+=SPEED;
        }
    }
//    public void update_2(){
//        map.put(1,new Bullets(1,2));
//        map.put(1,new Bullets(1,2));
//    }
    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
