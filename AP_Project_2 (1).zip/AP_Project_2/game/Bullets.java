package com.firstgdx.game;

import com.badlogic.gdx.math.Vector2;

import java.util.Vector;

public class Bullets {
    public int bulletLocn = 0;
    public int bulletSpeed = 0;

     public Bullets(int sentLocn,int sentVel){
         this.bulletLocn = sentLocn;
         this.bulletSpeed = sentVel;
     }
     public void update(){
         if(bulletLocn < 1500)
             bulletLocn += bulletSpeed;
     }
}
